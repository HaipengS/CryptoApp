CREATE DATABASE
  IF NOT EXISTS crypto;

USE
  crypto;

DROP TABLE IF EXISTS
  file_otps;

DROP TABLE IF EXISTS
  files_metadata;

DROP TABLE IF EXISTS
  decrypt_records;

DROP TABLE IF EXISTS
  files;

DROP TABLE IF EXISTS
  users;

CREATE TABLE
  users (
    userid INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL,
    pwdhash VARCHAR(256) NOT NULL,
    ban BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (userid),
    UNIQUE (username)
  );

ALTER TABLE
  users AUTO_INCREMENT = 13001;

CREATE TABLE
  files (
    fileid BIGINT PRIMARY KEY AUTO_INCREMENT,
    userid INT NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    s3_key VARCHAR(255) NOT NULL,
    salt TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_file_id (fileid),
    INDEX idx_created_at (created_at),
    CONSTRAINT fk_user_id FOREIGN KEY (userid) REFERENCES users (userid) ON DELETE CASCADE ON UPDATE CASCADE
  );

ALTER TABLE
  files AUTO_INCREMENT = 1001;

CREATE TABLE
  files_metadata (
    fileid BIGINT PRIMARY KEY,
    captions JSON,
    categories JSON,
    CONSTRAINT fk_fileid FOREIGN KEY (fileid) REFERENCES files (fileid) ON DELETE CASCADE ON UPDATE CASCADE
  );

CREATE TABLE
  decrypt_records (
    recordid BIGINT PRIMARY KEY AUTO_INCREMENT,
    userid INT NOT NULL,
    fileid BIGINT NOT NULL,
    wrong_attempt BOOLEAN NOT NULL,
    last_attempt_at DATETIME,
    FOREIGN KEY (userid) REFERENCES users (userid),
    FOREIGN KEY (fileid) REFERENCES files (fileid),
    INDEX idx_user_file (userid, fileid)
  );

ALTER TABLE
  decrypt_records AUTO_INCREMENT = 0001;

CREATE TABLE
  file_otps (
    otp_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    fileid BIGINT NOT NULL,
    userid INT NOT NULL,
    otp_code VARCHAR(8) NOT NULL,
    password_hash VARCHAR(256) NOT NULL, -- 添加密码哈希字段
    created_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (fileid) REFERENCES files (fileid),
    FOREIGN KEY (userid) REFERENCES users (userid),
    INDEX idx_otp_code (otp_code),
    INDEX idx_expires_at (expires_at)
  );

ALTER TABLE
  decrypt_records AUTO_INCREMENT = 0001;

INSERT INTO
  users (username, pwdhash) -- pwd = abc123!!
values
  (
    'Haoran_Zhao',
    'c17abb84cf9eccb946754188ebdae9f7e222099f4235780a7148e70cdd68dc07'
  );

INSERT INTO
  users (username, pwdhash) -- pwd = abc456!!
values
  (
    'Dong_Shu',
    '0ed2b78d3d238c17093ec87cf24d3c860da626a93385ee202b656d70d77c93b5'
  );

INSERT INTO
  users (username, pwdhash) -- pwd = abc789!!
values
  (
    'Haipeng_Shen',
    '8f42537f5334a6167fcbc6e0bbcb7bfd90203766837759509514c816a8991b63'
  );

DROP USER
  IF EXISTS 'cryptoapp-read-only';

DROP USER
  IF EXISTS 'cryptoapp-read-write';

CREATE USER
  'cryptoapp-read-only' IDENTIFIED BY 'abc123!!';

CREATE USER
  'cryptoapp-read-write' IDENTIFIED BY 'def456!!';

GRANT
SELECT
,
SHOW
  VIEW ON crypto.* TO 'cryptoapp-read-only';

GRANT
SELECT
,
SHOW
  VIEW,
INSERT
,
UPDATE
,
  DELETE,
DROP
,
  CREATE,
ALTER
  ON crypto.* TO 'cryptoapp-read-write';

FLUSH
  PRIVILEGES;