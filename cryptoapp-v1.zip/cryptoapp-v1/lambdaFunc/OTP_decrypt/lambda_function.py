import base64
import os
import boto3
import configparser
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import json
import pymysql
from pymysql.cursors import DictCursor
from datetime import datetime
from typing import Dict, Any, Optional, Tuple

def setup_aws_connections():
    """设置AWS连接信息"""
    config = configparser.ConfigParser()
    config_file = 'cryptoapp-config.ini'
    
    if not os.path.exists(config_file):
        raise Exception('Configuration file not found')
        
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    config.read(config_file)
    
    # S3 setup
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    bucketname = config.get('s3', 'bucket_name')
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    # RDS configuration
    db_config = {
        'host': config.get('rds', 'endpoint'),
        'port': int(config.get('rds', 'port_number')),
        'user': config.get('rds', 'user_name'),
        'password': config.get('rds', 'user_pwd'),
        'db': config.get('rds', 'db_name'),
        'cursorclass': DictCursor,
        'charset': 'utf8mb4'
    }
    
    return bucket, db_config

def get_db_connection(db_config: Dict[str, Any]):
    """获取数据库连接"""
    return pymysql.connect(**db_config)


def get_otp_info(conn, otp_code, fileid):
    """获取OTP信息并验证文件ID"""
    with conn.cursor() as cursor:
        sql = """
            SELECT o.*, f.s3_key, f.salt, f.original_file_name, f.userid
            FROM file_otps o
            JOIN files f ON o.fileid = f.fileid
            WHERE o.otp_code = %s 
            AND o.fileid = %s
            AND o.expires_at > NOW()
            AND o.used = FALSE
        """
        cursor.execute(sql, (otp_code, fileid))
        result = cursor.fetchone()
        if not result:
            raise Exception('Invalid or expired OTP')
        return result
def derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def decrypt_image(encrypted_data, password, salt):
    # Extract IV (first 16 bytes) and ciphertext
    iv = encrypted_data[:16]
    ciphertext = encrypted_data[16:]
    
    # Derive key
    key = derive_key(password, salt)
    
    # Create cipher
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    
    # Decrypt the data
    padded_data = decryptor.update(ciphertext) + decryptor.finalize()
    
    # Unpad the data
    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    
    return data.decode('utf-8')

def mark_otp_used(conn, otp_code):
    """标记OTP为已使用"""
    with conn.cursor() as cursor:
        sql = """
            UPDATE file_otps 
            SET used = TRUE 
            WHERE otp_code = %s
        """
        cursor.execute(sql, (otp_code,))
        conn.commit()


def lambda_handler(event, context):
    try:
        # Connect to AWS services
        try:
            bucket, db_config = setup_aws_connections()
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps('Failed to load configuration: ' + str(e))
            }
        
        # Get OTP code and fileid from body
        body = json.loads(event['body'])
        otp_code = body.get('otp')
        fileid = body.get('file_id')
        
        if not otp_code or not fileid:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required fields: otp and file_id'
                })
            }
        
        conn = None
        try:
            # Get database connection
            conn = get_db_connection(db_config)
            
            # Get OTP and file information
            try:
                otp_info = get_otp_info(conn, otp_code, fileid)
            except Exception as e:
                return {
                    'statusCode': 401,
                    'body': json.dumps({
                        'error': str(e)
                    })
                }
            
            # Verify the file ID matches
            if str(otp_info['fileid']) != str(fileid):
                return {
                    'statusCode': 401,
                    'body': json.dumps({
                        'error': 'OTP does not match the file ID'
                    })
                }
            
            # Get encrypted file from S3
            encrypted_data = bucket.Object(otp_info['s3_key']).get()['Body'].read()
            
            # Decrypt the file using the stored password
            salt = base64.b64decode(otp_info['salt'])
            decrypted_base64 = decrypt_image(
                encrypted_data,
                otp_info['password_hash'],
                salt
            )
            
            # Mark OTP as used
            mark_otp_used(conn, otp_code)
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'image': decrypted_base64,
                    'filename': otp_info['original_file_name']
                })
            }
            
        except Exception as e:
            if conn:
                conn.rollback()
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': str(e)
                })
            }
        finally:
            if conn:
                conn.close()
                
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }