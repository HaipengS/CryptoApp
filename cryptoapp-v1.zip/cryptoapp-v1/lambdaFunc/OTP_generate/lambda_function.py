import json
import secrets
import string
import boto3
import configparser
from datetime import datetime, timedelta
import pymysql
from pymysql.cursors import DictCursor
from typing import Dict, Any, Optional, Tuple
import os
import base64
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def setup_aws_connections():
    """设置AWS连接信息"""
    config = configparser.ConfigParser()
    config_file = 'cryptoapp-config.ini'
    
    if not os.path.exists(config_file):
        raise Exception('Configuration file not found')
        
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    config.read(config_file)
    
    # S3 setup
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    bucketname = config.get('s3', 'bucket_name')
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    # RDS configuration
    db_config = {
        'host': config.get('rds', 'endpoint'),
        'port': int(config.get('rds', 'port_number')),
        'user': config.get('rds', 'user_name'),
        'password': config.get('rds', 'user_pwd'),
        'db': config.get('rds', 'db_name'),
        'cursorclass': DictCursor,
        'charset': 'utf8mb4'
    }
    
    return bucket, db_config

def get_db_connection(db_config: Dict[str, Any]):
    """获取数据库连接"""
    return pymysql.connect(**db_config)

def validate_input(body: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """验证输入参数"""
    required_fields = ['userid', 'fileid', 'duration', 'login_password', 'encryption_password']
    
    # 检查必需字段
    for field in required_fields:
        if field not in body:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': f'Missing required field: {field}'
                })
            }
    
    # 验证字段类型和范围
    try:
        userid = int(body['userid'])
        fileid = int(body['fileid'])
        duration = int(body['duration'])
        
        if duration <= 0 or duration > 1440:  # 最长24小时（1440分钟）
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Duration must be between 1 and 1440 minutes'
                })
            }
    except ValueError:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid numeric value for userid, fileid, or duration'
            })
        }
    
    return None

def derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())
    
def verify_password(encrypted_data, password, salt):
    """验证密码是否正确"""
    try:
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        
        key = derive_key(password, salt)
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded_data = decryptor.update(ciphertext) + decryptor.finalize()
        
        unpadder = padding.PKCS7(128).unpadder()
        unpadder.update(padded_data) + unpadder.finalize()
        return True
    except Exception:
        return False

def get_file_info(conn, fileid: int) -> Optional[Dict]:
    """获取文件信息"""
    with conn.cursor() as cursor:
        sql = """
            SELECT s3_key, salt, original_file_name, userid
            FROM files
            WHERE fileid = %s
        """
        cursor.execute(sql, (fileid,))
        result = cursor.fetchone()
        if not result:
            return None
        return result

def generate_otp(conn, fileid: int, userid: int, duration: int, encryption_password: str) -> Dict[str, Any]:
    """生成OTP并存储到数据库"""
    try:
        # 生成8位随机OTP
        otp = ''.join(secrets.choice(string.ascii_uppercase + string.digits) 
                     for _ in range(8))
        
        # 设置创建和过期时间
        created_at = datetime.now()
        expires_at = created_at + timedelta(minutes=duration)
        
        # 存储OTP和加密密码
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO file_otps 
                (fileid, userid, otp_code, password_hash, created_at, expires_at)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (fileid, userid, otp, encryption_password, created_at, expires_at))
        
        conn.commit()
        return {
            'statusCode': 200,
            'body': json.dumps({
                'otp': otp,
                'expires_at': expires_at.isoformat()
            })
        }
        
    except Exception as e:
        conn.rollback()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'Database error: {str(e)}'
            })
        }

def check_user_exists(conn, userid: int) -> bool:
    """检查用户是否存在"""
    with conn.cursor() as cursor:
        sql = "SELECT * FROM users WHERE userid = %s"
        cursor.execute(sql, (userid,))
        result = cursor.fetchone()
        return result is not None

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda函数入口点"""
    try:
        # 设置AWS连接
        bucket, db_config = setup_aws_connections()
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'Failed to load configuration: {str(e)}'
            })
        }
    
    # 解析请求体
    try:
        body = json.loads(event['body']) if isinstance(event.get('body'), str) else event.get('body', {})
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body'
            })
        }
    
    # 验证必需参数
    required_fields = ['userid', 'fileid', 'duration', 'password']
    for field in required_fields:
        if field not in body:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': f'Missing required field: {field}'
                })
            }
    
    # 获取参数
    userid = str(body['userid'])
    fileid = int(body['fileid'])
    duration = int(body['duration'])
    password = body['password']
    
    # 验证duration范围
    if duration <= 0 or duration > 1440:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Duration must be between 1 and 1440 minutes'
            })
        }
    
    conn = None
    try:
        # 获取数据库连接
        conn = get_db_connection(db_config)
        
        # 检查用户是否存在
        if not check_user_exists(conn, userid):
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'User not exist, create a user first...'
                })
            }
        
        # 获取文件信息
        file_info = get_file_info(conn, fileid)
        if not file_info:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'error': 'File not found'
                })
            }
        
        # 检查文件所有权
        if str(file_info['userid']) != userid:
            return {
                'statusCode': 403,
                'body': json.dumps({
                    'error': 'Access denied: File does not belong to this user'
                })
            }
        
        # 获取加密文件并验证密码
        encrypted_data = bucket.Object(file_info['s3_key']).get()['Body'].read()
        salt = base64.b64decode(file_info['salt'])
        
        if not verify_password(encrypted_data, password, salt):
            return {
                'statusCode': 401,
                'body': json.dumps({
                    'error': 'Invalid password'
                })
            }
        
        # 生成OTP
        return generate_otp(conn, fileid, userid, duration, password)
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'Server error: {str(e)}'
            })
        }
    finally:
        if conn:
            conn.close()
