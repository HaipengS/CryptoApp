import json
import base64
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from msrest.authentication import CognitiveServicesCredentials
import os
import configparser
from io import BytesIO

def lambda_handler(event, context):
    """
    AWS Lambda handler for image moderation using Azure Computer Vision API
    
    Parameters:
        event (dict): AWS Lambda event object containing the base64 encoded image
        context (object): AWS Lambda context object
    
    Returns:
        dict: Lambda response with status code and results
    """
    try:
        # Get Azure credentials from configuration file
        config = configparser.ConfigParser()
        if os.path.exists('azure_config.ini'):
            config.read('azure_config.ini')
            computervision_subscription_key = config['AzureVision']['subscription_key']
            computervision_endpoint = config['AzureVision']['endpoint']
        else:
            return {
                'statusCode': 500,
                'body': json.dumps('Azure configuration file not found')
            }

        
        # Validate input data
        if 'body' not in event:
            return {
                'statusCode': 400,
                'body': json.dumps('No image data provided in request body')
            }
            
        # Read image data from request body
        request_body = json.loads(event['body'])
        if 'image' not in request_body:
            return {
                'statusCode': 400,
                'body': json.dumps('No image field in request body')
            }
            
        img_base64 = request_body['image']
        
        # Initialize Azure Computer Vision client
        computervision_client = ComputerVisionClient(
            computervision_endpoint, 
            CognitiveServicesCredentials(computervision_subscription_key)
        )
        
        # Decode image data
        image_data = base64.b64decode(img_base64)
        image_stream = BytesIO(image_data)
        
        # Analyze image
        description_results = computervision_client.describe_image_in_stream(image_stream)

        
        # Extract metadata from image analysis
        metadata = {}
        if description_results.captions:
            metadata['caption'] = [
                caption.text for caption in description_results.captions
            ]
        
        # Return image metadata
        return {
            'statusCode': 200,
            'body': json.dumps(metadata.get('caption', []))
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error while processing image',
                'error': str(e)
            })
        }