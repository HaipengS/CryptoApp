import base64
import os
import boto3
import configparser
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import json
import pymysql
from datetime import datetime

def setup_aws_connections():
    config = configparser.ConfigParser()
    config_file = 'cryptoapp-config.ini'
    
    if not os.path.exists(config_file):
        raise Exception('Configuration file not found')
        
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    config.read(config_file)
    
    # S3 setup
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    bucketname = config.get('s3', 'bucket_name')
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    # RDS configuration
    db_config = {
        'host': config.get('rds', 'endpoint'),
        'port': int(config.get('rds', 'port_number')),
        'user': config.get('rds', 'user_name'),
        'password': config.get('rds', 'user_pwd'),
        'db': config.get('rds', 'db_name'),
    }
    
    return bucket, db_config

def get_db_connection(db_config):
    return pymysql.connect(
        host=db_config['host'],
        port=db_config['port'],
        user=db_config['user'],
        password=db_config['password'],
        db=db_config['db'],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def check_user_exists(db_config, user_id):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM users WHERE userid = %s"
            cursor.execute(sql, (user_id,))
            result = cursor.fetchone()
            return result is not None
    finally:
        conn.close()

def get_file_info(db_config, file_id):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = """
                SELECT s3_key, salt, original_file_name, userid
                FROM files
                WHERE fileid = %s
            """
            cursor.execute(sql, (file_id,))
            result = cursor.fetchone()
            if not result:
                raise Exception('File not found')
            return result
    finally:
        conn.close()
def derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def decrypt_image(encrypted_data, password, salt):
    # Extract IV (first 16 bytes) and ciphertext
    iv = encrypted_data[:16]
    ciphertext = encrypted_data[16:]
    
    # Derive key
    key = derive_key(password, salt)
    
    # Create cipher
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    
    # Decrypt the data
    padded_data = decryptor.update(ciphertext) + decryptor.finalize()
    
    # Unpad the data
    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    
    return data.decode('utf-8')

def check_decrypt_attempts(db_config, userid, fileid):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = """
                SELECT COUNT(*) as wrong_count 
                FROM (
                    SELECT wrong_attempt 
                    FROM decrypt_records 
                    WHERE userid = %s AND fileid = %s 
                    ORDER BY last_attempt_at DESC 
                    LIMIT 3
                ) recent 
                WHERE wrong_attempt = 1
            """
            cursor.execute(sql, (userid, fileid))
            result = cursor.fetchone()
            return result['wrong_count']
    finally:
        conn.close()

def record_decrypt_attempt(db_config, userid, fileid, is_correct):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO decrypt_records 
                (userid, fileid, wrong_attempt, last_attempt_at)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(sql, (
                userid,
                fileid,
                not is_correct,
                datetime.utcnow()
            ))
        conn.commit()
    finally:
        conn.close()

def verify_password(encrypted_data, password, salt):
    try:
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        
        key = derive_key(password, salt)
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded_data = decryptor.update(ciphertext) + decryptor.finalize()
        
        unpadder = padding.PKCS7(128).unpadder()
        unpadder.update(padded_data) + unpadder.finalize()
        return True
    except Exception:
        return False

def lambda_handler(event, context):
    try:
        # Connect to AWS services
        try:
            bucket, db_config = setup_aws_connections()
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps('Failed to load configuration: ' + str(e))
            }
        
        # Get fileid, userid and password from headers
        body = json.loads(event['body'])
        fileid = body['file_id']
        userid = body['user_id']
        password = body['password']
        
        if not fileid or not password or not userid:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required headers: fileid, userid or password'
                })
            }
            
        # Check if user exists
        if not check_user_exists(db_config, userid):
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'User not exist, create a user first...'
                })
            }
        
        # Check if user is locked
        wrong_count = check_decrypt_attempts(db_config, userid, fileid)
        if wrong_count >= 3:
            return {
                'statusCode': 401,
                'body': json.dumps({
                    'error': 'Account is locked due to too many wrong attempts'
                })
            }
        
        # Get file information
        try:
            file_info = get_file_info(db_config, fileid)
            
            # Check if the file belongs to the user
            if str(file_info['userid']) != userid:
                return {
                    'statusCode': 403,
                    'body': json.dumps({
                        'error': 'Access denied: File does not belong to this user'
                    })
                }
                
        except Exception as e:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'error': str(e)
                })
            }
        
        # Get encrypted file from S3
        encrypted_data = bucket.Object(file_info['s3_key']).get()['Body'].read()
        
        # Verify password
        salt = base64.b64decode(file_info['salt'])
        is_password_correct = verify_password(encrypted_data, password, salt)
        
        # Record the attempt
        record_decrypt_attempt(db_config, userid, fileid, is_password_correct)
        
        if not is_password_correct:
            remaining_attempts = 3 - check_decrypt_attempts(db_config, userid, fileid)
            return {
                'statusCode': 401,
                'body': json.dumps({
                    'error': f'Wrong password. {remaining_attempts} attempts remaining'
                })
            }
        
        # If we get here, password is correct, proceed with full decryption
        decrypted_base64 = decrypt_image(encrypted_data, password, salt)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'image': decrypted_base64,
                'filename': file_info['original_file_name']
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }