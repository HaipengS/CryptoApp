import base64
import os
import uuid
import boto3
import configparser
from datetime import datetime
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import secrets
import json
import pymysql

def setup_aws_connections():
    config = configparser.ConfigParser()
    config_file = 'cryptoapp-config.ini'
    
    if not os.path.exists(config_file):
        raise Exception('Configuration file not found')
        
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    config.read(config_file)
    
    # S3 setup
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    bucketname = config.get('s3', 'bucket_name')
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    # RDS configuration
    db_config = {
        'host': config.get('rds', 'endpoint'),
        'port': int(config.get('rds', 'port_number')),
        'user': config.get('rds', 'user_name'),
        'password': config.get('rds', 'user_pwd'),
        'db': config.get('rds', 'db_name'),
    }
    
    return bucket, db_config

def get_db_connection(db_config):
    return pymysql.connect(
        host=db_config['host'],
        port=db_config['port'],
        user=db_config['user'],
        password=db_config['password'],
        db=db_config['db'],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def generate_salt():
    return secrets.token_bytes(16)

def derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def encrypt_image(image_base64, password):
    if isinstance(image_base64, bytes):
        image_base64 = image_base64.decode('utf-8')
    
    salt = generate_salt()
    key = derive_key(password, salt)
    
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    
    data = image_base64.encode('utf-8')
    
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    
    final_data = iv + encrypted_data
    
    return (
        base64.b64encode(final_data).decode('utf-8'),
        base64.b64encode(salt).decode('utf-8'),
        base64.b64encode(key).decode('utf-8')
    )

def store_file_metadata(db_config, user_id, original_filename, s3_key, salt_base64):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO files 
                (userid, original_file_name, s3_key, salt, created_at) 
                VALUES (%s, %s, %s, %s, %s)
                """
            cursor.execute(sql, (
                user_id,
                original_filename,
                s3_key,
                salt_base64,
                datetime.utcnow()
            ))
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()

def check_user_exists(db_config, user_id):
    conn = get_db_connection(db_config)
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM users WHERE userid = %s"
            cursor.execute(sql, (user_id,))
            result = cursor.fetchone()
            return result is not None
    finally:
        conn.close()

def lambda_handler(event, context):
    try:
        # Connect to AWS services
        try:
            bucket, db_config = setup_aws_connections()
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps('Failed to load configuration: ' + str(e))
            }
        
        # Parse the request body
        body = json.loads(event['body'])
        image_base64 = body['image']
        password = body['password']
        user_id = body['user_id']
        original_filename = body['filename']
        
        # Check if user exists
        if not check_user_exists(db_config, user_id):
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'User not exist, create a user first...'
                })
            }
        
        # Encrypt the image
        encrypted_base64, salt_base64, key_base64 = encrypt_image(image_base64, password)
        
        # Generate a unique S3 key
        s3_key = f"encrypted/{uuid.uuid4()}"
        
        # Upload the encrypted image to S3
        encrypted_data = base64.b64decode(encrypted_base64)
        bucket.put_object(
            Key=s3_key,
            Body=encrypted_data,
            ServerSideEncryption='AES256'
        )
        
        # Store the file metadata in the database
        file_id = store_file_metadata(
            db_config=db_config,
            user_id=user_id,
            original_filename=original_filename,
            s3_key=s3_key,
            salt_base64=salt_base64
        )
        
        # Return the response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'file_id': file_id,
                'salt': salt_base64,
                's3_key': s3_key
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }