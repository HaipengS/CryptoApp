#!/bin/bash

# 创建临时目录
mkdir -p lambda_package
cd lambda_package

# 创建 Python 3.12 虚拟环境
python3.12 -m venv venv
source venv/bin/activate

# 验证 Python 版本
python --version  # 应该显示 Python 3.12.x

# 安装所需的包
pip install --upgrade pip
pip install cryptography==41.0.7  # 使用固定版本
pip install pymysql==1.1.0
pip install boto3==1.33.13
pip install configparser==5.3.0

# 创建部署目录
mkdir -p package
cp -r venv/lib/python3.12/site-packages/* package/

# 复制 Lambda 函数代码和配置文件
cp ../lambda_function.py package/
cp ../cryptoapp-config.ini package/

# 创建zip包
cd package
zip -r9 ../../lambda_deployment.zip .

# 清理
cd ../..
rm -rf lambda_package

echo "Deployment package created: lambda_deployment.zip"