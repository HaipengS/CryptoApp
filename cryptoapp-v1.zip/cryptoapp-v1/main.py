import os
import configparser
import boto3
import mysql.connector
import hashlib
import getpass
import json
import requests
import base64
from tkinter import filedialog
import tkinter as tk
from datetime import datetime
    

def setup_aws_connections():
    config = configparser.ConfigParser()
    config_file = 'cryptoapp-config.ini'
    
    if not os.path.exists(config_file):
        raise Exception('Configuration file not found')
        
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    config.read(config_file)
    
    # S3 setup
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    bucketname = config.get('s3', 'bucket_name')
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    # RDS configuration
    db_config = {
        'host': config.get('rds', 'endpoint'),
        'port': int(config.get('rds', 'port_number')),
        'user': config.get('rds', 'user_name'),
        'password': config.get('rds', 'user_pwd'),
        'db': config.get('rds', 'db_name'),
    }
    
    return bucket, db_config

def hash_password(password):
    """Hash the password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def connect_to_db(db_config):
    """Establish connection to MySQL database"""
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except mysql.connector.Error as err:
        print(f"Error connecting to database: {err}")
        return None

def check_user_banned(cursor, username):
    """Check if user is banned"""
    cursor.execute("SELECT ban FROM users WHERE username = %s", (username,))
    result = cursor.fetchone()
    return result and bool(result[0])

def check_user_exists(cursor, username):
    """Check if user exists in database"""
    cursor.execute("SELECT userid FROM users WHERE username = %s", (username,))
    return cursor.fetchone() is not None

def verify_credentials(cursor, username, password):
    """Verify user credentials"""
    # First check if user exists
    if not check_user_exists(cursor, username):
        return None, "User does not exist"
        
    # Check password and ban status
    hashed_pwd = hash_password(password)
    cursor.execute("""
        SELECT userid, ban FROM users 
        WHERE username = %s AND pwdhash = %s
    """, (username, hashed_pwd))
    result = cursor.fetchone()
    
    if not result:
        return None, "Incorrect password"
    if result[1]:  # Check ban status
        return None, "Account is banned"
        
    return result[0], "Success"  # Return userid and success message

def register_user(conn, cursor, username, password):
    """Register a new user"""
    try:
        # Check if username already exists
        cursor.execute("SELECT username FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            print("Username already exists!")
            return False
        
        # Insert new user
        hashed_pwd = hash_password(password)
        cursor.execute("""
            INSERT INTO users (username, pwdhash, ban) 
            VALUES (%s, %s, 0)
        """, (username, hashed_pwd))
        conn.commit()
        print("Registration successful!")
        return True
    except mysql.connector.Error as err:
        print(f"Error registering user: {err}")
        return False

def authenticate_user():
    """Main authentication function"""
    # Setup connections
    bucket, db_config = setup_aws_connections()
    conn = connect_to_db(db_config)
    if not conn:
        return None
    
    cursor = conn.cursor(buffered=True)
    
    while True:
        print("\n1. Login")
        print("2. Register")
        print("3. Exit")
        choice = input("Please choose an option (1-3): ")
        
        if choice == "1":  # Login
            username = input("Username: ")
            
            # First check if user exists
            if not check_user_exists(cursor, username):
                print("User does not exist. Please register or try a different username.")
                continue
            
            attempts = 0
            while attempts < 3:
                password = getpass.getpass("Password: ")
                userid, message = verify_credentials(cursor, username, password)
                
                if userid is not None:
                    print("Login successful!")
                    cursor.close()
                    conn.close()
                    return username, userid
                
                if message == "Account is banned":
                    print("This account has been banned.")
                    break
                    
                attempts += 1
                remaining = 3 - attempts
                if remaining > 0:
                    print(f"{message}. {remaining} attempts remaining.")
                
            if attempts >= 3 and message != "Account is banned":
                # Ban user after 3 failed attempts
                try:
                    cursor.execute("""
                        UPDATE users SET ban = 1 
                        WHERE username = %s
                    """, (username,))
                    conn.commit()
                    print("Account has been banned due to too many failed attempts.")
                except mysql.connector.Error as err:
                    print(f"Error banning user: {err}")
                    conn.rollback()
            
        elif choice == "2":  # Register
            username = input("Choose a username: ")
            password = getpass.getpass("Choose a password: ")
            confirm_pwd = getpass.getpass("Confirm password: ")
            
            if password != confirm_pwd:
                print("Passwords do not match!")
                continue
            
            if register_user(conn, cursor, username, password):
                continue
                
        elif choice == "3":  # Exit
            cursor.close()
            conn.close()
            return None
        
        else:
            print("Invalid choice. Please try again.")

def files_list(bucket, userid, db_config):
    """List files for the current user with their metadata"""
    try:
        conn = connect_to_db(db_config)
        if not conn:
            print("Error: Could not connect to database")
            return
            
        cursor = conn.cursor(dictionary=True)
        
        # Query to get files with their metadata
        query = """
            SELECT 
                f.fileid,
                f.original_file_name,
                f.created_at,
                m.captions,
                m.categories
            FROM files f
            LEFT JOIN files_metadata m ON f.fileid = m.fileid
            WHERE f.userid = %s
            ORDER BY f.created_at DESC
        """
        
        cursor.execute(query, (userid,))
        files = cursor.fetchall()
        
        if not files:
            print("\nNo files found.")
            return
            
        print("\nYour Files:")
        print("-" * 100)
        print(f"{'ID':<10} {'Filename':<30} {'Created At':<20} {'Categories':<20} {'Caption':<20}")
        print("-" * 100)
        
        for file in files:
            # Format categories if they exist
            categories = "N/A"
            if file['categories']:
                try:
                    categories_list = json.loads(file['categories'])
                    categories = ", ".join(categories_list[:2])  # Show first 2 categories
                    if len(categories_list) > 2:
                        categories += "..."
                except json.JSONDecodeError:
                    categories = "Error parsing categories"
            
            # Format caption if it exists
            caption = "N/A"
            if file['captions']:
                try:
                    captions_list = json.loads(file['captions'])
                    if captions_list:
                        caption = (captions_list[0][:17] + "...") if len(captions_list[0]) > 17 else captions_list[0]
                except json.JSONDecodeError:
                    caption = "Error parsing caption"
            
            # Format the output line
            print(f"{file['fileid']:<10} {file['original_file_name'][:27]+'...' if len(file['original_file_name'])>27 else file['original_file_name']:<30} {file['created_at'].strftime('%Y-%m-%d %H:%M'):<20} {categories:<20} {caption:<20}")
        
        print("-" * 100)
        total_files = len(files)
        print(f"\nTotal files: {total_files}")
        
        # Ask if user wants to see detailed information for a specific file
        while True:
            choice = input("\nEnter file ID to see details (or press Enter to return to menu): ").strip()
            if not choice:
                break
                
            try:
                fileid = int(choice)
                file_details = next((f for f in files if f['fileid'] == fileid), None)
                
                if file_details:
                    print("\nDetailed File Information:")
                    print("-" * 40)
                    print(f"File ID: {file_details['fileid']}")
                    print(f"Filename: {file_details['original_file_name']}")
                    print(f"Created: {file_details['created_at'].strftime('%Y-%m-%d %H:%M:%S')}")
                    
                    # Show captions if they exist
                    if file_details['captions']:
                        try:
                            captions = json.loads(file_details['captions'])
                            print("\nCaptions:")
                            for caption in captions[:3]:  # Show first 3 captions
                                print(f"- {caption}")
                            if len(captions) > 3:
                                print("...")
                        except json.JSONDecodeError:
                            print("Captions: Error parsing captions")
                    
                    # Show all categories if they exist
                    if file_details['categories']:
                        try:
                            categories = json.loads(file_details['categories'])
                            print("\nCategories:")
                            for category in categories:
                                print(f"- {category}")
                        except json.JSONDecodeError:
                            print("Categories: Error parsing categories")
                else:
                    print("File not found.")
            except ValueError:
                print("Invalid file ID. Please enter a number.")
                
    except mysql.connector.Error as err:
        print(f"Database error: {err}")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()


def encrypt_file(bucket, userid, db_config):
    """Encrypt a file using AWS API Gateway"""
    # Create and hide the tkinter root window
    root = tk.Tk()
    root.withdraw()
    
    # Open file dialog for selecting a file
    file_path = filedialog.askopenfilename(
        title="Select file to encrypt",
        filetypes=[("Image files", "*.jpg *.jpeg *.png *.gif *.bmp")]
    )
    
    if not file_path:
        print("No file selected.")
        return
        
    # Get the original filename
    original_filename = os.path.basename(file_path)
    
    try:
        # Read the file and convert to base64
        with open(file_path, 'rb') as file:
            file_content = file.read()
            base64_content = base64.b64encode(file_content).decode('utf-8')
        
        # Get password from user
        password = getpass.getpass("Enter encryption password: ")
        confirm_password = getpass.getpass("Confirm encryption password: ")
        
        if password != confirm_password:
            print("Passwords do not match!")
            return
            
        # Step 1: Encrypt the file
        print("\nEncrypting file...")
        payload = {
            'image': base64_content,
            'password': password,
            'user_id': userid,
            'filename': original_filename
        }
        
        encrypt_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/encrypt'
        response = requests.post(encrypt_url, json=payload)
        
        if response.status_code != 200:
            error_msg = response.json().get('error', 'Unknown error occurred')
            print(f"\nError encrypting file: {error_msg}")
            return
            
        encryption_result = response.json()
        file_id = encryption_result['file_id']
        
        # Step 2: Get image captions
        print("Getting image captions...")
        caption_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/check/caption'
        caption_response = requests.post(caption_url, json={'image': base64_content})
        
        if caption_response.status_code == 200:
            captions = caption_response.json()  # This is already the array of captions
            # Step 3: Check content moderation
            print("Checking content moderation...")
            moderation_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/check/moderation'
            moderation_response = requests.post(moderation_url, json={'image': base64_content})
            
            if moderation_response.status_code == 400:
                print("\nWarning: Image flagged by content moderation.")
                print("Removing file from system...")
                
                # Delete the file record
                try:
                    conn = mysql.connector.connect(**db_config)
                    cursor = conn.cursor()
                    
                    # Delete from files table (cascade will handle files_metadata)
                    cursor.execute("DELETE FROM files WHERE fileid = %s", (file_id,))
                    
                    conn.commit()
                    print("File removed from database.")
                    
                    # Delete from S3
                    bucket.delete_objects(
                        Delete={
                            'Objects': [
                                {'Key': encryption_result['s3_key']}
                            ]
                        }
                    )
                    print("File removed from storage.")
                    return
                    
                except mysql.connector.Error as err:
                    print(f"Error removing file from database: {err}")
                finally:
                    if 'cursor' in locals():
                        cursor.close()
                    if 'conn' in locals():
                        conn.close()
            
            elif moderation_response.status_code == 200:
                # File passed moderation check, store metadata
                moderation_data = moderation_response.json()
                
                try:
                    conn = mysql.connector.connect(**db_config)
                    cursor = conn.cursor()
                    
                    # Insert or update files_metadata with both captions and categories
                    cursor.execute("""
                        INSERT INTO files_metadata (fileid, captions, categories)
                        VALUES (%s, %s, %s)
                        ON DUPLICATE KEY UPDATE 
                            captions = VALUES(captions),
                            categories = VALUES(categories)
                    """, (
                        file_id,
                        json.dumps(captions),
                        json.dumps(moderation_data.get('categories', []))
                    ))
                    
                    conn.commit()
                    print("Metadata stored successfully.")
                    
                except mysql.connector.Error as err:
                    print(f"Warning: Could not store metadata: {err}")
                finally:
                    if 'cursor' in locals():
                        cursor.close()
                    if 'conn' in locals():
                        conn.close()
        
        # Final success message
        if moderation_response.status_code == 200:
            print("\nFile encrypted and processed successfully!")
            print(f"File ID: {file_id}")
            print(f"S3 Key: {encryption_result['s3_key']}")
            print("\nIMPORTANT: Please save your encryption password securely.")
            print("You will need it to decrypt the file later.")
            
    except FileNotFoundError:
        print("Error: Could not read the selected file.")
    except requests.exceptions.RequestException as e:
        print(f"Error connecting to service: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def decrypt_file(bucket, userid):
    """Decrypt a file using AWS API Gateway"""
    try:
        # Get file ID from user
        fileid = input("\nEnter the File ID to decrypt: ").strip()
        if not fileid:
            print("No file ID provided.")
            return
            
        # Get password
        password = getpass.getpass("Enter decryption password: ")
        if not password:
            print("No password provided.")
            return
            
        # Prepare request payload
        payload = {
            'file_id': fileid,
            'user_id': str(userid),
            'password': password
        }
        
        # Make API request
        print("\nAttempting to decrypt file...")
        api_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/decrypt'
        response = requests.post(api_url, json=payload)
        
        if response.status_code == 200:
            # Successful decryption
            result = response.json()
            
            # Create save file dialog
            root = tk.Tk()
            root.withdraw()
            
            # Get original filename
            original_filename = result['filename']
            file_extension = os.path.splitext(original_filename)[1]
            
            # Open file dialog for saving
            save_path = filedialog.asksaveasfilename(
                title="Save Decrypted File",
                initialfile=original_filename,
                defaultextension=file_extension,
                filetypes=[("All Files", "*.*")]
            )
            
            if save_path:
                # Decode base64 image and save
                image_data = base64.b64decode(result['image'])
                with open(save_path, 'wb') as f:
                    f.write(image_data)
                print(f"\nFile successfully decrypted and saved to: {save_path}")
            else:
                print("\nSave operation cancelled.")
                
        elif response.status_code == 401:
            # Handle authentication errors
            error_data = response.json()
            error_message = error_data.get('error', 'Authentication failed')
            print(f"\nError: {error_message}")
            
        elif response.status_code == 403:
            print("\nError: You don't have permission to decrypt this file.")
            
        elif response.status_code == 404:
            print("\nError: File not found.")
            
        else:
            error_msg = response.json().get('error', 'Unknown error occurred')
            print(f"\nError: {error_msg}")
            
    except requests.exceptions.RequestException as e:
        print(f"\nError connecting to decryption service: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

def generate_otp(bucket, userid):
    """Generate One-Time Pad for file sharing"""
    try:
        # Get file ID from user
        fileid = input("\nEnter the File ID to generate OTP for: ").strip()
        if not fileid:
            print("No file ID provided.")
            return
            
        # Get encryption password
        password = getpass.getpass("Enter the file's encryption password: ")
        if not password:
            print("No password provided.")
            return
            
        # Get duration
        while True:
            try:
                duration = int(input("Enter OTP validity duration in minutes (1-1440): "))
                if 1 <= duration <= 1440:
                    break
                print("Duration must be between 1 and 1440 minutes (24 hours).")
            except ValueError:
                print("Please enter a valid number.")
        
        # Prepare request payload
        payload = {
            'userid': userid,
            'fileid': int(fileid),
            'duration': duration,
            'password': password
        }
        
        # Make API request
        print("\nGenerating OTP...")
        api_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/otp/generate'
        response = requests.post(api_url, json=payload)
        
        if response.status_code == 200:
            # Successful OTP generation
            result = response.json()
            otp = result['otp']
            expires_at = datetime.fromisoformat(result['expires_at'])
            
            print("\nOTP generated successfully!")
            print(f"OTP code: {otp}")
            print(f"Expires at: {expires_at.strftime('%Y-%m-%d %H:%M:%S')}")
            print("\nPlease share this OTP with the intended recipient.")
            print("Note: The OTP can only be used once and will expire at the time shown above.")
            
        elif response.status_code == 401:
            print("\nError: Invalid encryption password.")
            
        elif response.status_code == 403:
            print("\nError: You don't have permission to generate OTP for this file.")
            
        elif response.status_code == 404:
            print("\nError: File not found.")
            
        else:
            error_msg = response.json().get('error', 'Unknown error occurred')
            print(f"\nError: {error_msg}")
            
    except requests.exceptions.RequestException as e:
        print(f"\nError connecting to OTP generation service: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

def otp_decrypt(bucket, userid):
    """Decrypt a file using OTP"""
    try:
        # Get file ID and OTP from user
        fileid = input("\nEnter the File ID: ").strip()
        if not fileid:
            print("No file ID provided.")
            return
            
        otp_code = input("Enter the OTP code: ").strip()
        if not otp_code:
            print("No OTP provided.")
            return
            
        # Prepare request payload
        payload = {
            'otp': otp_code,
            'file_id': fileid
        }
        
        # Make API request
        print("\nAttempting to decrypt file...")
        api_url = 'https://mc5jtp0f8b.execute-api.us-east-2.amazonaws.com/final-prod/otp/decrypt'
        response = requests.post(api_url, json=payload)
        
        if response.status_code == 200:
            # Successful decryption
            result = response.json()
            
            # Create save file dialog
            root = tk.Tk()
            root.withdraw()
            
            # Get original filename
            original_filename = result['filename']
            file_extension = os.path.splitext(original_filename)[1]
            
            # Open file dialog for saving
            save_path = filedialog.asksaveasfilename(
                title="Save Decrypted File",
                initialfile=original_filename,
                defaultextension=file_extension,
                filetypes=[("All Files", "*.*")]
            )
            
            if save_path:
                # Decode base64 image and save
                image_data = base64.b64decode(result['image'])
                with open(save_path, 'wb') as f:
                    f.write(image_data)
                print(f"\nFile successfully decrypted and saved to: {save_path}")
            else:
                print("\nSave operation cancelled.")
                
        elif response.status_code == 401:
            print("\nError: Invalid or expired OTP code.")
            
        elif response.status_code == 404:
            print("\nError: File not found.")
            
        else:
            error_msg = response.json().get('error', 'Unknown error occurred')
            print(f"\nError: {error_msg}")
            
    except requests.exceptions.RequestException as e:
        print(f"\nError connecting to decryption service: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

def command_menu(bucket, username, userid, db_config):
    """Main command menu system"""
    while True:
        print("\nCommand Menu:")
        print("1. Files List")
        print("2. Encrypt")
        print("3. Decrypt")
        print("4. Generate OTP")
        print("5. OTP Decrypt")
        print("6. Switch User")
        print("7. End")
        
        try:
            choice = input("\nPlease select a command (1-7): ").strip()
            
            if choice == "1":
                files_list(bucket, userid, db_config)
            
            elif choice == "2":
                encrypt_file(bucket, userid, db_config)
            
            elif choice == "3":
                decrypt_file(bucket, userid)
            
            elif choice == "4":
                generate_otp(bucket, userid)
            
            elif choice == "5":
                otp_decrypt(bucket, userid)
            
            elif choice == "6":
                print("\nSwitching user...")
                return "switch_user"
            
            elif choice == "7":
                print("\nThank you for using the system. Goodbye!")
                return "exit"
            
            else:
                print("\nInvalid choice. Please select a number between 1 and 7.")
                
        except Exception as e:
            print(f"\nAn error occurred: {e}")
            print("Please try again.")

# Update the main authentication loop
def main():
    while True:
        try:
            # Get initial AWS connections
            bucket, db_config = setup_aws_connections()
            
            while True:
                # Authenticate user
                auth_result = authenticate_user()
                if not auth_result:
                    return  # Exit if authentication is cancelled
                
                username, userid = auth_result
                print(f"\nWelcome back, {username}!")
                
                # Enter command menu
                result = command_menu(bucket, username, userid, db_config)
                
                if result == "exit":
                    return  # Exit the program
                elif result == "switch_user":
                    continue  # Go back to authentication
                
        except Exception as e:
            print(f"\nA system error occurred: {e}")
            print("Restarting the system...")
            continue

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nProgram terminated by user.")
    except Exception as e:
        print(f"\nFatal error: {e}")
    finally:
        print("\nGoodbye!")